#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

struct cpu cpus[NCPU];

struct proc proc[NPROC];

int count=1;

int cpu0 = -1;
int cpu1 = -1;
int cpu2 = -1;
int cpu3 = -1;

int sleeping= -1;
int zombie= -1;
int unused= -1;

struct proc *initproc;

int nextpid = 1;
struct spinlock pid_lock;
struct spinlock cpu0_head;
struct spinlock cpu1_head;
struct spinlock cpu2_head;
struct spinlock cpu3_head;
struct spinlock sleeping_head;
struct spinlock zombie_head;
struct spinlock unused_head;

extern void forkret(void);
static void freeproc(struct proc *p);

extern char trampoline[]; // trampoline.S
extern uint64 cas (volatile void *addr, int expected, int newval);

// helps ensure that wakeups of wait()ing
// parents are not lost. helps obey the
// memory model when using p->parent.
// must be acquired before any p->lock.
struct spinlock wait_lock;

// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.

int
remove_cs(struct proc *pred, struct proc *curr, struct proc *p){
  while (curr->next <= p->next) {
  if ( p->index == curr->index) {
      pred->next = curr->next;
      return curr->index; 
    }
  release(&pred->lock);
  printf("%d",132); //1
    pred = curr;
    curr = &proc[curr->next];
    acquire(&curr->lock);
  }

return -1;
}

int
remove_from_list(struct proc *p){
  struct proc *pred;
  struct proc *curr;
  int ret=-1;
  switch (p->state)
  {
  case SLEEPING:
    acquire(&sleeping_head);
    pred=&proc[sleeping];
    acquire(&pred->lock);
    curr=&proc[pred->next];
    acquire(&curr->lock);
    ret=remove_cs(pred, curr, p);
    release(&curr->lock);
    release(&pred->lock);
    release(&sleeping_head);
    printf("%d",158); //2
    return ret;
    
  case ZOMBIE:
    acquire(&zombie_head);
    pred=&proc[zombie];
    acquire(&pred->lock);
    curr=&proc[pred->next];
    acquire(&curr->lock);
    ret=remove_cs(pred, curr, p);
    release(&curr->lock);
    release(&pred->lock);
    release(&zombie_head);
    printf("%d",171); //3
    return ret;
    
  case UNUSED:
    acquire(&unused_head);
    pred=&proc[unused];
    acquire(&pred->lock);
    curr=&proc[pred->next];
    acquire(&curr->lock);
    ret=remove_cs(pred, curr, p);
    release(&curr->lock);
    release(&pred->lock);
    release(&unused_head);
    printf("%d",184); //4
    return ret;
  
  case RUNNABLE:
    switch (p->cpu_num)
    {
    case 0:
      acquire(&cpu0_head);
      pred=&proc[cpu0];
      acquire(&pred->lock);
      curr=&proc[pred->next];
      acquire(&curr->lock);
      ret=remove_cs(pred, curr, p);
      release(&curr->lock);
      release(&pred->lock);
      release(&unused_head);
      printf("%d",200); //5
      return ret;

    case 1:
      acquire(&cpu1_head);
      pred=&proc[cpu1];
      acquire(&pred->lock);
      curr=&proc[pred->next];
      acquire(&curr->lock);
      ret=remove_cs(pred, curr, p);
      release(&curr->lock);
      release(&pred->lock);
      release(&unused_head);
      printf("%d",213); //6
      return ret;  

    case 2:
      acquire(&cpu2_head);
      pred=&proc[cpu2];
      acquire(&pred->lock);
      curr=&proc[pred->next];
      acquire(&curr->lock);
      ret=remove_cs(pred, curr, p);
      release(&curr->lock);
      release(&pred->lock);
      release(&unused_head);
      printf("%d",226); //7
      return ret;

    case 3:
      acquire(&cpu3_head);
      pred=&proc[cpu3];
      acquire(&pred->lock);
      curr=&proc[pred->next];
      acquire(&curr->lock);
      ret=remove_cs(pred, curr, p);
      release(&curr->lock);
      release(&pred->lock);
      release(&unused_head);
      printf("%d",239); //8
      return ret;

    default:
      return ret;
    }
  default:
    printf("the problem is here\n");
    break;
  }

  return p->index;
}

int
insert_cs(struct proc *pred, struct proc *curr, struct proc *p){
  while (curr->next != -1) {
    release(&pred->lock);
    printf("%d\n",257); //9
    pred = curr;
    curr = &proc[curr->next];
    acquire(&curr->lock);
    }
    printf("wjdfjh\n");
    curr->next = p->index;
    p->next=-1;
    return p->index; 
}

int
insert_to_list(struct proc *p){
  struct proc *pred;
  struct proc *curr;
  int ret=-1;
  switch (p->state)
  {
  case SLEEPING:
    acquire(&sleeping_head);
    pred=&proc[sleeping];
    acquire(&pred->lock);
    curr=&proc[pred->next];
    acquire(&curr->lock);
    ret=insert_cs(pred, curr, p);
    release(&curr->lock);
    release(&pred->lock);
    release(&sleeping_head);
    printf("%d",284); //10
    return ret;
    
  case ZOMBIE:
    acquire(&zombie_head);
    pred=&proc[zombie];
    acquire(&pred->lock);
    curr=&proc[pred->next];
    acquire(&curr->lock);
    ret=insert_cs(pred, curr, p);
    release(&curr->lock);
    release(&pred->lock);
    release(&zombie_head);
    printf("%d",297); //11
    return ret;
    
  case UNUSED:
    acquire(&unused_head);
    pred=&proc[unused];
    acquire(&pred->lock);
    curr=&proc[pred->next];
    acquire(&curr->lock);
    ret=insert_cs(pred, curr, p);
    release(&curr->lock);
    release(&pred->lock);
    release(&unused_head);
    printf("%d\n",310); 
    return ret;
    
  case RUNNABLE:
    switch (p->cpu_num)
    {
    case 0:
      acquire(&cpu0_head);
      pred=&proc[cpu0];
      acquire(&pred->lock);
      curr=&proc[pred->next];
      acquire(&curr->lock);
      ret=insert_cs(pred, curr, p);
      release(&curr->lock);
      release(&pred->lock);
      release(&unused_head);
      printf("%d",326);
      return ret;

    case 1:
      acquire(&cpu1_head);
      pred=&proc[cpu1];
      acquire(&pred->lock);
      curr=&proc[pred->next];
      acquire(&curr->lock);
      ret=insert_cs(pred, curr, p);
      release(&curr->lock);
      release(&pred->lock);
      release(&unused_head);
      return ret;  

    case 2:
      acquire(&cpu2_head);
      pred=&proc[cpu2];
      acquire(&pred->lock);
      curr=&proc[pred->next];
      acquire(&curr->lock);
      ret=insert_cs(pred, curr, p);
      release(&curr->lock);
      release(&pred->lock);
      release(&unused_head);
      printf("%d",351);
      return ret;

    case 3:
      acquire(&cpu3_head);
      pred=&proc[cpu3];
      acquire(&pred->lock);
      curr=&proc[pred->next];
      acquire(&curr->lock);
      ret=insert_cs(pred, curr, p);
      release(&curr->lock);
      release(&pred->lock);
      release(&unused_head);
      printf("%d",364);
      return ret;

    default:
      return ret;
    }
    
  default:
    printf("the problem is here\n");
    return ret;
  }

  return p->index;
}

void
proc_mapstacks(pagetable_t kpgtbl) {
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
  }
}

// initialize the proc table at boot time.
void
procinit(void)
{
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
  initlock(&wait_lock, "wait_lock");
  for(p = proc; p < &proc[NPROC]; p++) {
      initlock(&p->lock, "proc");
      p->kstack = KSTACK((int) (p - proc));
      if(p->pid==0){
        unused=0;
        p->next=-1;
        printf("yupidu Inbar\n");
      }
      else if(p->pid==1){
        proc[unused].next=1;
        p->next=-1;
        printf("yupidu Lihi\n");
      }
      else insert_to_list(p);
      printf("p->index= %d\n",p->index);
  }
}

// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
  int id = r_tp();
  return id;
}


// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void) {
  int id = cpuid();
  struct cpu *c = &cpus[id];
  return c;
}

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void) {
  push_off();
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
  pop_off();
  return p;
}

int
allocpid() {
  printf("entered allocpid");
  int pid;
  do {
      pid = nextpid;
      printf("\npid from allocpid= %d\n",pid);
      //nextpid++;
  } while(cas(&nextpid, pid, pid+1));
    
  // acquire(&pid_lock);
  // pid = nextpid;
  // nextpid = nextpid + 1;
  // release(&pid_lock);

  return pid;
}




// Look in the process table for an UNUSED proc.
// If found, initialize state required to run in the kernel,
// and return with p->lock held.
// If there are no free procs, or a memory allocation fails, return 0.
static struct proc*
allocproc(void)
{
  struct proc *p;
acquire(&unused_head);
  for(p = &proc[unused]; p->next != -1; p = &proc[p->next]) {
    acquire(&p->lock);
    if(p->state == UNUSED) {
      goto found;
    } else {
      release(&p->lock);
      printf("%d",396);
    }
  }
  release(&unused_head);
  printf("%d",399);
  return 0;

found:
  p->pid = allocpid();
  printf("no problem with allocpid");
  p->state = USED;
  release(&unused_head);
  printf("%d",407);

  // Allocate a trapframe page.
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    freeproc(p);
    release(&p->lock);
    printf("%d",413);
    release(&unused_head);
    printf("%d",415);
    return 0;
  }

  // An empty user page table.
  p->pagetable = proc_pagetable(p);
  if(p->pagetable == 0){
    freeproc(p);
    release(&p->lock);
    release(&unused_head);
    printf("%d",425);
    return 0;
  }

  // Set up new context to start executing at forkret,
  // which returns to user space.
  memset(&p->context, 0, sizeof(p->context));
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;
  release(&unused_head);
  printf("%d",435);
  return p;
}

// free a proc structure and the data hanging from it,
// including user pages.
// p->lock must be held.
static void
freeproc(struct proc *p)
{
  if(p->trapframe)
    kfree((void*)p->trapframe);
  p->trapframe = 0;
  if(p->pagetable)
    proc_freepagetable(p->pagetable, p->sz);
  p->pagetable = 0;
  p->sz = 0;
  p->pid = 0;
  p->parent = 0;
  p->name[0] = 0;
  p->chan = 0;
  p->killed = 0;
  p->xstate = 0;
  int index=remove_from_list(p);
  p->state = UNUSED;
  insert_to_list(&proc[index]);
}

// Create a user page table for a given process,
// with no user memory, but with trampoline pages.
pagetable_t
proc_pagetable(struct proc *p)
{
  pagetable_t pagetable;

  // An empty page table.
  pagetable = uvmcreate();
  if(pagetable == 0)
    return 0;

  // map the trampoline code (for system call return)
  // at the highest user virtual address.
  // only the supervisor uses it, on the way
  // to/from user space, so not PTE_U.
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
              (uint64)trampoline, PTE_R | PTE_X) < 0){
    uvmfree(pagetable, 0);
    return 0;
  }

  // map the trapframe just below TRAMPOLINE, for trampoline.S.
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
              (uint64)(p->trapframe), PTE_R | PTE_W) < 0){
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    uvmfree(pagetable, 0);
    return 0;
  }

  return pagetable;
}

// Free a process's page table, and free the
// physical memory it refers to.
void
proc_freepagetable(pagetable_t pagetable, uint64 sz)
{
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
  uvmfree(pagetable, sz);
}

// a user program that calls exec("/init")
// od -t xC initcode
uchar initcode[] = {
  0x17, 0x05, 0x00, 0x00, 0x13, 0x05, 0x45, 0x02,
  0x97, 0x05, 0x00, 0x00, 0x93, 0x85, 0x35, 0x02,
  0x93, 0x08, 0x70, 0x00, 0x73, 0x00, 0x00, 0x00,
  0x93, 0x08, 0x20, 0x00, 0x73, 0x00, 0x00, 0x00,
  0xef, 0xf0, 0x9f, 0xff, 0x2f, 0x69, 0x6e, 0x69,
  0x74, 0x00, 0x00, 0x24, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00
};

// Set up first user process.
void
userinit(void)
{
  struct proc *p;

  p = allocproc();
  initproc = p;
  
  // allocate one user page and copy init's instructions
  // and data into it.
  uvminit(p->pagetable, initcode, sizeof(initcode));
  p->sz = PGSIZE;

  // prepare for the very first "return" from kernel to user.
  p->trapframe->epc = 0;      // user program counter
  p->trapframe->sp = PGSIZE;  // user stack pointer

  safestrcpy(p->name, "initcode", sizeof(p->name));
  p->cwd = namei("/");

  p->state = RUNNABLE;
  // p->cpu_num=cpuid();
  // cpu0[0]=0;
  // cpu0[1]=0;

  release(&p->lock);
  printf("%d",544);
}

// Grow or shrink user memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
  uint sz;
  struct proc *p = myproc();

  sz = p->sz;
  if(n > 0){
    if((sz = uvmalloc(p->pagetable, sz, sz + n)) == 0) {
      return -1;
    }
  } else if(n < 0){
    sz = uvmdealloc(p->pagetable, sz, sz + n);
  }
  p->sz = sz;
  return 0;
}

// Create a new process, copying the parent.
// Sets up child kernel stack to return as if from fork() system call.
int
fork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *p = myproc();

  // Allocate process.
  if((np = allocproc()) == 0){
    return -1;
  }

  // Copy user memory from parent to child.
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    freeproc(np);
    release(&np->lock);
    printf("%d",586);
    return -1;
  }
  np->sz = p->sz;

  // copy saved user registers.
  *(np->trapframe) = *(p->trapframe);

  // Cause fork to return 0 in the child.
  np->trapframe->a0 = 0;

  // increment reference counts on open file descriptors.
  for(i = 0; i < NOFILE; i++)
    if(p->ofile[i])
      np->ofile[i] = filedup(p->ofile[i]);
  np->cwd = idup(p->cwd);

  safestrcpy(np->name, p->name, sizeof(p->name));

  pid = np->pid;
  np->cpu_num=p->cpu_num;

// struct cpu *c;  
// int j = 1;
// for (c = cpus ; c <&cpus[NCPU] ; c++)
// {
// if(myproc()->pid == c->proc->pid)
//   break;
// else
//   j++;
// }

//  switch (i)
//  {
//  case 1:
//    proc[cpu1[1]].next=np->index;
//    cpu1[1]=np->index;
//    break;
//  case 2:
//    proc[cpu2[1]].next=np->index;
//    cpu2[1]=np->index;
//    break;
// case 3:
//    proc[cpu3[1]].next=np->index;
//    cpu3[1]=np->index;
//    break;
// case 1:
//    proc[cpu1[1]].next=np->index;
//    cpu1[1]=np->index;
//    break;  
 
//  default:
//    break;
//  }


  // np->cpu_num=myproc()->cpu_num;
  // np->cpu_num=mycpu();
  //   printf("the cpu running is: %d",mycpu);

  //   }
 // np->cpu_num=p->cpu_num; //need to make sure we are setting the cpu num for the first process.

  release(&np->lock);
  printf("%d",649);

  acquire(&wait_lock);
  np->parent = p;
  release(&wait_lock);
  printf("%d",655);

  acquire(&np->lock);
  np->state = RUNNABLE;
  release(&np->lock);
  printf("%d",660);

  return pid;
}

// Pass p's abandoned children to init.
// Caller must hold wait_lock.
void
reparent(struct proc *p)
{
  struct proc *pp;

  for(pp = proc; pp < &proc[NPROC]; pp++){
    if(pp->parent == p){
      pp->parent = initproc;
      wakeup(initproc);
    }
  }
}

// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait().
void
exit(int status)
{
  struct proc *p = myproc();

  if(p == initproc)
    panic("init exiting");

  // Close all open files.
  for(int fd = 0; fd < NOFILE; fd++){
    if(p->ofile[fd]){
      struct file *f = p->ofile[fd];
      fileclose(f);
      p->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(p->cwd);
  end_op();
  p->cwd = 0;

  acquire(&wait_lock);

  // Give any children to init.
  reparent(p);

  // Parent might be sleeping in wait().
  wakeup(p->parent);
  
  acquire(&p->lock);

  p->xstate = status;
  p->state = ZOMBIE;
// switch (cpuid())
//   {
//   case 0:
//     proc[zombie[1]].next=proc[cpu0[0]].index;
//     zombie[1]=cpu0[0];
//     cpu0[0]=proc[cpu0[0]].next;
//     break;
//       case 1:
//     proc[zombie[1]].next=proc[cpu1[0]].index;
//     zombie[1]=cpu1[0];
//     cpu1[0]=proc[cpu1[0]].next;
//     break;
//       case 2:
//     proc[zombie[1]].next=proc[cpu2[0]].index;
//     zombie[1]=cpu2[0];
//     cpu2[0]=proc[cpu2[0]].next;
//     break;
//       case 3:
//     proc[zombie[1]].next=proc[cpu3[0]].index;
//     zombie[1]=cpu3[0];
//     cpu3[0]=proc[cpu3[0]].next;
//     break;
  
//   default:
//     break;
//   }  

  release(&wait_lock);
  printf("%d",745);

  // Jump into the scheduler, never to return.
  sched();
  panic("zombie exit");
}

// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.
int
wait(uint64 addr)
{
  struct proc *np;
  int havekids, pid;
  struct proc *p = myproc();

  acquire(&wait_lock);

  for(;;){
    // Scan through table looking for exited children.
    havekids = 0;
    for(np = proc; np < &proc[NPROC]; np++){
      if(np->parent == p){
        // make sure the child isn't still in exit() or swtch().
        acquire(&np->lock);

        havekids = 1;
        if(np->state == ZOMBIE){
          // Found one.
          pid = np->pid;
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&np->xstate,
                                  sizeof(np->xstate)) < 0) {
            release(&np->lock);
            release(&wait_lock);
            printf("%d",779);
            return -1;
          }
          freeproc(np);
          release(&np->lock);
          release(&wait_lock);
          printf("%d",785);
          return pid;
        }
        release(&np->lock);
        printf("%d",789);
      }
    }

    // No point waiting if we don't have any children.
    if(!havekids || p->killed){
      release(&wait_lock);
      printf("%d",796);
      return -1;
    }
    
    // Wait for a child to exit.
    sleep(p, &wait_lock);  //DOC: wait-sleep
  }
}

// Per-CPU process scheduler.
// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns.  It loops, doing:
//  - choose a process to run.
//  - swtch to start running that process.
//  - eventually that process transfers control
//    via swtch back to the scheduler.
void
scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();
  
  c->proc = 0;
  for(;;){
    // Avoid deadlock by ensuring that devices can interrupt.
    intr_on();
  int i= cpuid();

 switch (i) {
  case 0:
    acquire(&cpu0_head);
    p=&proc[cpu0];
    release(&cpu0_head);
    printf("%d",829);
    break;
  case 1:
    acquire(&cpu1_head);
    p=&proc[cpu1];
    release(&cpu1_head);
    printf("%d",835);
    break;  
  case 2:
    acquire(&cpu2_head);
    p=&proc[cpu2];
    release(&cpu2_head);
    printf("%d",840);
    break;
  case 3:
    acquire(&cpu3_head);
    p=&proc[cpu3];
    release(&cpu3_head);
    printf("%d",847);
    break;

 default:
  p=myproc();
   break;
  }
    printf("here0\n");
      acquire(&p->lock);
      p->state = RUNNING;
      c->proc = p;
      printf("here0 %d\n",p->pid);
    struct proc *pr;
      if(ticks%50==0){
        for (pr=&proc[cpu0]; pr->next!=-1; pr=&proc[pr->next]){
          printf("(%d,%d)",pr->pid,pr->index);
        }
        printf("(%d,%d)",pr->pid,pr->index);
      }
    // for(p = proc; p < &proc[NPROC]; p++) {
    //   acquire(&p->lock);
      
    //  if(p->state == RUNNABLE) {
    //     // Switch to chosen process.  It is the process's job
    //     // to release its lock and then reacquire it
    //     // before jumping back to us.
    //     p->state = RUNNING;
    //     c->proc = p;
        swtch(&c->context, &p->context);
 printf("here0 %d\n",p->pid);
        // Process is done running for now.
        // It should have changed its p->state before coming back.
        c->proc = 0;
      //}
      release(&p->lock);
      printf("%d",882);
    
  //}
}
}


// Switch to scheduler.  Must hold only p->lock
// and have changed proc->state. Saves and restores
// intena because intena is a property of this
// kernel thread, not this CPU. It should
// be proc->intena and proc->noff, but that would
// break in the few places where a lock is held but
// there's no process.
void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if(!holding(&p->lock))
    panic("sched p->lock");
  if(mycpu()->noff != 1)
    panic("sched locks");
  if(p->state == RUNNING)
    panic("sched running");
  if(intr_get())
    panic("sched interruptible");

  intena = mycpu()->intena;
  swtch(&p->context, &mycpu()->context);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void
yield(void)
{
  struct proc *p = myproc();
  acquire(&p->lock);
  p->state = RUNNABLE;
  sched();
  release(&p->lock);
  printf("%d",924);
}

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
  printf("%d",937);

  if (first) {
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    first = 0;
    fsinit(ROOTDEV);
  }

  usertrapret();
}

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();
  
  // Must acquire p->lock in order to
  // change p->state and then call sched.
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
  release(lk);
  printf("%d",965);

  // Go to sleep.
  p->chan = chan;
  switch (cpuid())
  {
  case 0:
    acquire(&sleeping_head);
    acquire(&cpu0_head);
    insert_to_list(p);
    release(&cpu0_head);
    release(&sleeping_head);
    printf("%d",978);
    // proc[sleeping[1]].next=proc[cpu0[0]].index;
    // sleeping[1]=cpu0[0];
    // cpu0[0]=proc[cpu0[0]].next;
    break;
      case 1:
      acquire(&sleeping_head);
    acquire(&cpu1_head);
    insert_to_list(p);
    release(&cpu1_head);
    release(&sleeping_head);
    printf("%d",989);
    // proc[sleeping[1]].next=proc[cpu1[0]].index;
    // sleeping[1]=cpu1[0];
    // cpu1[0]=proc[cpu1[0]].next;
    break;
      case 2:
      acquire(&sleeping_head);
    acquire(&cpu2_head);
    insert_to_list(p);
    release(&cpu2_head);
    release(&sleeping_head);
    printf("%d",1000);
    // proc[sleeping[1]].next=proc[cpu2[0]].index;
    // sleeping[1]=cpu2[0];
    // cpu2[0]=proc[cpu2[0]].next;
     break;
      case 3:
      acquire(&sleeping_head);
    acquire(&cpu3_head);
    insert_to_list(p);
    release(&cpu3_head);
    release(&sleeping_head);
    printf("%d",1010);
    // proc[sleeping[1]].next=proc[cpu3[0]].index;
    // sleeping[1]=cpu3[0];
    // cpu3[0]=proc[cpu3[0]].next;
    break;
  
  default:
    break;
  }
  p->state = SLEEPING;

  sched();

  // Tidy up.
  p->chan = 0;

  // Reacquire original lock.
  release(&p->lock);
  printf("%d",1029);
  acquire(lk);
}

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
  struct proc *p;
  acquire(&sleeping_head);
  for(p = &proc[sleeping]; p->index <= -1; p=&proc[p->next]) {
    if(p->cpu_num == cpuid()){
      acquire(&p->lock);
      remove_from_list(p);
      switch (p->cpu_num)
      {
      case 0:
        acquire(&cpu0_head);
        p->state = RUNNABLE;
        insert_to_list(p);
        release(&cpu0_head);
        printf("%d",1050);
        break;
      case 1:
        acquire(&cpu1_head);
        p->state = RUNNABLE;
        insert_to_list(p);
        release(&cpu1_head);
        printf("%d",1058);
        break;
      case 2:
        acquire(&cpu2_head);
        p->state = RUNNABLE;
        insert_to_list(p);
        release(&cpu2_head);
        break;
      case 3:
        acquire(&cpu3_head);
        p->state = RUNNABLE;
        insert_to_list(p);
        release(&cpu3_head);
        printf("%d",1071);
        break;
      default:
        break;
      }
      
      release(&p->lock);
      printf("%d",1078);
    }
  }
}

// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->pid == pid){
      p->killed = 1;
      if(p->state == SLEEPING){
        // Wake process from sleep().
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;
}

// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
  struct proc *p = myproc();
  if(user_dst){
    return copyout(p->pagetable, dst, src, len);
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}

// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
  struct proc *p = myproc();
  if(user_src){
    return copyin(p->pagetable, dst, src, len);
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}

// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
  for(p = proc; p < &proc[NPROC]; p++){
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    printf("%d %s %s", p->pid, state, p->name);
    printf("\n");
  }
}
