#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void
main(int fd, char c)
{
  int pid;
  for(int i=0;i<1;i++){
    
    if ((pid=fork())!=0)
    {
        printf("the pid is: %d\n",pid);
    }


  }
}

